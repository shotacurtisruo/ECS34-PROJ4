Markdown on CStreetMap:

    CStreetMap is a class that represents a streetmap.
    
    It contains abstract structs as well as virtual functions that we implemented through 
    OpenStreetmap.cpp. The SNode struct is meant to represent a node in the street map, while SWay
    represents a way (connected nodes). 

    The methods will be further explained in the COpenStreetMap markdown.  