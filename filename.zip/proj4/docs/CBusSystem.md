

    CBusSystem is meant to model public transit.
     
    It is an abstract class that includes virtual methods that we implemented through
    CSVBusSystem.cpp. It also includes the abstract classes SStop and SRoute that represent bus stops and bus routes that we also implemented. 

    The methods will be explained in the CCSVBusSystem markdown. 
    