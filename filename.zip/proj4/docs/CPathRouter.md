Markdown on CPathRouter: 
    
    This class is the meant to model paths that can be directed and weighted.

    It contains a bunch of virtual methods that we implemented in DijkstraPathRouter.cpp. 

    The methods will be explained in the CDijkstraPathRouter markdown. 