
# ECS34_PROJ4

For all of the classes and structures, the PIMPL method was used as SImplementation class/struct 
was declared in the header files, but we implemented them in the src files using a pointer to the SImplementation called DImplementation. To understand this implementation, refereced lecture notes and:
    https://www.geeksforgeeks.org/pimpl-idiom-in-c-with-examples/

For the FindShortestPath method in DijkstraPathRouter.cpp, we referenced: 
    https://www.geeksforgeeks.org/dijkstras-shortest-path-algorithm-greedy-algo-7/

This reference helped with understanding the expat library and its functions that we implemented 
in the CXMLReader class. 
    https://www.xml.com/pub/1999/09/expat/index.html

In order to understand how to implement COpenStreetMap, had to study this link for a while. 
    https://wiki.openstreetmap.org/wiki/OSM_XML

Used ChatGPT to help us understand what we needed in a Makefile and the general skeleton of one. 
